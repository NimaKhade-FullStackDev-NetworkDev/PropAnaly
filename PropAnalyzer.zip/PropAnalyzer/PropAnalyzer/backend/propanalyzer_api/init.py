# -*- coding: utf-8 -*-
"""پکیج اصلی Django"""