# 🏠 PropAnalyzer - پلتفرم تحلیل بازار مسکن ایران

پروژه کامل برای تحلیل و پیش‌بینی قیمت املاک با هوش مصنوعی

## 🚀 ویژگی‌ها
- جمع‌آوری خودکار داده از سایت‌های املاک
- پیش‌بینی قیمت با مدل‌های ML
- رابط کاربری مدرن با Next.js
- اجرای یکپارچه با Docker

## ⚡ اجرای سریع
```bash
# کلون کردن پروژه
git clone <repository>
cd propanalyzer

# اجرای با Docker
cd docker
docker-compose up --build

# دسترسی به سرویس‌ها:
# فرانت‌اند: http://localhost:3000
# بک‌اند: http://localhost:8000
# هوش مصنوعی: http://localhost:8001